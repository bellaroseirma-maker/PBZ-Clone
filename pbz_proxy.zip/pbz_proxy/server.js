"use strict";

/**
 * Transform reverse proxy (PBZ -> tvoj origin, npr. ngrok)
 * - HTML: uklanja CSP/<base>/SRI/nonce, prepisuje href/src/srcset (uz <base>)
 * - CSS: prepisuje url(...) i @import apsolutne PBZ URL-ove na relativne
 * - JS/JSON: prepisuje "https://(www.)?pbz.hr" (i escaped) na relativno ("/")
 * - Static: passthrough
 * - POST/PUT/DELETE/PATCH/OPTIONS: blokirano (demo sigurnost)
 *
 * Start:
 *   # HTTPS lokalno (preporučeno)
 *   $env:LOCAL_CERT="C:\pbz_proxy\localhost.pem"
 *   $env:LOCAL_KEY="C:\pbz_proxy\localhost-key.pem"
 *   node server.js
 *   ngrok http https://localhost:8443
 *
 *   # ili HTTP fallback:
 *   node server.js
 *   ngrok http 8080
 */

const fs = require("fs");
const path = require("path");
const http = require("http");
const https = require("https");
const express = require("express");
const cheerio = require("cheerio");

const UPSTREAM = "https://www.pbz.hr";
const CERT = process.env.LOCAL_CERT || path.join(__dirname, "localhost.pem");
const KEY  = process.env.LOCAL_KEY  || path.join(__dirname, "localhost-key.pem");
const HTTPS_PORT = 8443;
const HTTP_PORT  = 8080;

const app = express();
app.set("trust proxy", true); // bitno kad je iza ngrok-a
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// korisno za brzu provjeru u DevTools → Response Headers
app.use((req, res, next) => {
  res.setHeader("X-Proxy", "pbz-transform");
  next();
});

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

const PBZ_HOST_RX = /^https?:\/\/(www\.)?pbz\.hr(?=\/|$)/i;
const PBZ_ABS_ANY_RX = /(https?:)?\/\/(www\.)?pbz\.hr/gi;
const PBZ_ESC_RX = /https?:\\\/\\\/(www\.)?pbz\.hr/gi;     // za minificirani/escaped JS
const PBZ_ESC_PR_RX = /\\\/\\\/(www\.)?pbz\.hr/gi;         // protocol-relative u escaped obliku

function shouldIgnoreURL(u) {
  return /^(\s*javascript:|\s*data:|\s*mailto:|\s*tel:|\s*blob:|\s*#)/i.test(u || "");
}
function isPbzAbs(u) { return PBZ_HOST_RX.test(u || ""); }

function toLocalPath(urlOrPath) {
  try {
    const u = new URL(urlOrPath);
    if (isPbzAbs(u.href)) return u.pathname + (u.search || "");
    return urlOrPath; // drugi host (CDN) ostavi kako jest
  } catch {
    if (typeof urlOrPath === "string" && urlOrPath.startsWith("/")) return urlOrPath;
    return urlOrPath;
  }
}

// ---------- HTML transform (poštuje <base>) ----------
function transformHtml(html, pageAbsUrl) {
  const $ = cheerio.load(html, { decodeEntities: false });

  // zapiši <base href> prije uklanjanja
  const baseTagHref = $('base[href]').attr('href');
  const pageBase = (() => {
    try { return new URL(baseTagHref || "", pageAbsUrl).href; }
    catch { return pageAbsUrl; }
  })();

  // ukloni CSP i <base>
  $('meta[http-equiv="Content-Security-Policy"]').remove();
  $('base').remove();

  // ukloni atribute koji koče lokalne resurse
  $('script, link').each((_, el) => {
    $(el).removeAttr('integrity');
    $(el).removeAttr('crossorigin');
    $(el).removeAttr('referrerpolicy');
    $(el).removeAttr('nonce');
  });

  // preload-as-style -> stylesheet
  $('link[rel="preload"][as="style"]').each((_, el) => {
    $(el).attr('rel', 'stylesheet');
    $(el).removeAttr('as');
    $(el).removeAttr('onload');
  });

  // rewrite href/src/action
  const ATTRS = ['href','src','action'];
  $('a, link, script, img, source, iframe, video, audio, form').each((_, el) => {
    for (const a of ATTRS) {
      const val = $(el).attr(a);
      if (!val || shouldIgnoreURL(val)) continue;
      let abs = null;
      try { abs = new URL(val, pageBase).href; } catch { abs = null; }
      if (!abs) continue;

      if (isPbzAbs(abs)) {
        $(el).attr(a, toLocalPath(abs));
      }
    }

    // srcset
    const ss = $(el).attr('srcset');
    if (ss) {
      const parts = ss.split(',').map(s => s.trim()).filter(Boolean);
      const repl = parts.map(p => {
        const toks = p.split(/\s+/);
        const u = toks[0];
        if (shouldIgnoreURL(u)) return p;
        let abs = null;
        try { abs = new URL(u, pageBase).href; } catch { abs = null; }
        if (abs && isPbzAbs(abs)) toks[0] = toLocalPath(abs);
        return toks.join(' ');
      }).join(', ');
      $(el).attr('srcset', repl);
    }
  });

  // inline style url(...) apsolutne PBZ → lokalno
  const urlRx = /url\(\s*(['"]?)([^'")]+)\1\s*\)/gi;
  $('[style]').each((_, el) => {
    const v = $(el).attr('style');
    if (!v) return;
    const out = v.replace(urlRx, (m, q, u) => {
      if (shouldIgnoreURL(u)) return m;
      let abs = null;
      try { abs = new URL(u, pageBase).href; } catch { abs = null; }
      if (abs && isPbzAbs(abs)) return 'url(' + toLocalPath(abs) + ')';
      return m;
    });
    $(el).attr('style', out);
  });

  return $.html();
}

// ---------- CSS transform ----------
function transformCss(cssText, pageAbsUrl) {
  const pageBase = pageAbsUrl; // dovoljno nam je page URL kao base
  // url(...)
  cssText = cssText.replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi, (m, q, u) => {
    if (shouldIgnoreURL(u)) return m;
    try {
      const abs = new URL(u, pageBase).href;
      if (isPbzAbs(abs)) return "url(" + toLocalPath(abs) + ")";
    } catch {}
    return m;
  });
  // @import ...
  cssText = cssText.replace(/@import\s+(?:url\()?['"]?([^'")\s]+)['"]?\)?\s*;/gi, (m, u) => {
    if (shouldIgnoreURL(u)) return m;
    try {
      const abs = new URL(u, pageBase).href;
      if (isPbzAbs(abs)) return "@import url(" + toLocalPath(abs) + ");";
    } catch {}
    return m;
  });
  return cssText;
}

// ---------- JS/JSON transform ----------
function transformJsJson(text) {
  // apsolutni -> relativni
  // https://www.pbz.hr/foo  -> /foo
  // https://pbz.hr/foo      -> /foo
  // escaped varijante u bundleovima
  return text
    .replace(PBZ_ABS_ANY_RX, "")      // https://(www.)?pbz.hr
    .replace(PBZ_ESC_RX, "")          // https:\/\/(www.)?pbz.hr
    .replace(PBZ_ESC_PR_RX, "");      // \/\/(www.)?pbz.hr
}

// ----------------- ROUTES (Express 5) -----------------
app.get(/.*/, async (req, res) => {
  try {
    const upstreamUrl = new URL(req.originalUrl, UPSTREAM).toString();
    const r = await fetch(upstreamUrl, {
      method: 'GET',
      headers: {
        'user-agent': req.headers['user-agent'] || UA,
        'accept': req.headers['accept'] || '*/*',
        'accept-language': req.headers['accept-language'] || 'en-US,en;q=0.9',
        'cookie': req.headers['cookie'] || ''
      },
      redirect: 'manual'
    });

    // kopiraj headere, ali skini one koji smetaju transformaciji
    const ct = r.headers.get('content-type') || '';
    res.status(r.status);
    r.headers.forEach((v, k) => {
      const kl = k.toLowerCase();
      // ne prenosimo CSP/HSTS/XFO (može blokirati), ni content-length/encoding kad mijenjamo tijelo
      if (['content-security-policy','x-frame-options','strict-transport-security'].includes(kl)) return;
      if ((/text\/html|javascript|json|text\/css/i).test(ct) && ['content-length','content-encoding'].includes(kl)) return;
      res.setHeader(k, v);
    });

    if (/text\/html/i.test(ct)) {
      const html = await r.text();
      const out = transformHtml(html, new URL(req.originalUrl, UPSTREAM).href);
      res.setHeader('content-type', 'text/html; charset=utf-8');
      res.send(out);

    } else if (/text\/css/i.test(ct)) {
      let css = await r.text();
      css = transformCss(css, new URL(req.originalUrl, UPSTREAM).href);
      res.setHeader('content-type', ct);
      res.send(css);

    } else if (/javascript|json/i.test(ct)) {
      let body = await r.text();
      body = transformJsJson(body);
      res.setHeader('content-type', ct);
      res.send(body);

    } else {
      // binarni/static → passthrough
      const buf = Buffer.from(await r.arrayBuffer());
      res.send(buf);
    }
  } catch (e) {
    res.status(502).send("Upstream fetch error");
  }
});

// Blokiraj mutating metode (demo sigurnost)
for (const m of ["post","put","delete","patch","options"]) {
  app[m](/.*/, (req, res) => {
    res.status(200).json({ demo: true, message: "Demo nacin: zahtjev prema upstreamu je onemogucen." });
  });
}

// --------- Start (HTTPS ako PEM postoji; inače HTTP fallback) ---------
const hasTLS = fs.existsSync(KEY) && fs.existsSync(CERT);

if (hasTLS) {
  const opts = { key: fs.readFileSync(KEY), cert: fs.readFileSync(CERT) };
  https.createServer(opts, app).listen(HTTPS_PORT, () => {
    console.log(`PBZ transform proxy (HTTPS) at https://localhost:${HTTPS_PORT}`);
    console.log(`Ngrok: ngrok http https://localhost:${HTTPS_PORT}`);
  });
} else {
  http.createServer(app).listen(HTTP_PORT, () => {
    console.log(`PBZ transform proxy (HTTP) at http://localhost:${HTTP_PORT}`);
    console.log(`Ngrok: ngrok http ${HTTP_PORT}`);
  });
}
