"use strict";

/**
 * Exact-domain reverse proxy za www.pbz.hr s logiranjem aktivnosti.
 * - GET/HEAD: čisti passthrough (bez transformacije) -> CSS/JS rade identično
 * - POST/PUT/DELETE/PATCH: blokirano (demo)
 * - Logira svaki zahtjev u logs/activity.jsonl (JSON Lines)
 * - HTTPS na 443 s mkcert certom za "www.pbz.hr" (ili promijeni putanje)
 *
 * PREREQ:
 *   - hosts: 127.0.0.1  www.pbz.hr
 *   - mkcert -install && mkcert "www.pbz.hr" u C:\pbz_proxy
 */

const fs = require("fs");
const path = require("path");
const https = require("https");
const express = require("express");
const { Readable } = require("stream");

const UPSTREAM = "https://www.pbz.hr";
const CERT = path.join(__dirname, "www.pbz.hr.pem");
const KEY  = path.join(__dirname, "www.pbz.hr-key.pem");
const PORT = 443;

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// --- Log setup ---
const LOG_DIR = path.join(__dirname, "logs");
const LOG_FILE = path.join(LOG_DIR, "activity.jsonl");
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

function logActivity(entry) {
  try {
    fs.appendFile(LOG_FILE, JSON.stringify(entry) + "\n", () => {});
  } catch (_) {}
}

// mali helper za IP i vrijeme
function clientIp(req) {
  return (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "").toString();
}
function nowIso() {
  return new Date().toISOString();
}

// GET/HEAD passthrough (Express 5: regex rute)
app.get(/.*/, async (req, res) => {
  const t0 = Date.now();
  const upstreamUrl = new URL(req.originalUrl, UPSTREAM).toString();

  try {
    const r = await fetch(upstreamUrl, {
      method: "GET",
      headers: {
        "user-agent": req.headers["user-agent"] || "Mozilla/5.0",
        "accept": req.headers["accept"] || "*/*",
        "accept-language": req.headers["accept-language"] || "en-US,en;q=0.9",
        "cookie": req.headers["cookie"] || ""
      },
      redirect: "manual"
    });

    // kopiraj headere 1:1
    res.status(r.status);
    r.headers.forEach((v, k) => res.setHeader(k, v));

    const ct = r.headers.get("content-type") || "";
    const cl = r.headers.get("content-length");
    let bytes = cl ? parseInt(cl, 10) : 0;

    // ako nema content-length, brojaj dok streama
    if (!cl && r.body) {
      const tee = Readable.fromWeb(r.body);
      tee.on("data", (chunk) => { bytes += chunk.length; });
      tee.on("end", () => {
        const entry = {
          ts: nowIso(),
          dur_ms: Date.now() - t0,
          method: "GET",
          path: req.originalUrl,
          upstream: upstreamUrl,
          status: r.status,
          bytes,
          content_type: ct,
          referer: req.headers["referer"] || null,
          ua: req.headers["user-agent"] || null,
          ip: clientIp(req)
        };
        logActivity(entry);
        console.log(`[GET] ${req.originalUrl} -> ${r.status} (${entry.dur_ms}ms, ${bytes}B)`);
      });
      tee.pipe(res);
    } else {
      // imamo content-length: samo preusmjeri body
      if (r.body) Readable.fromWeb(r.body).pipe(res);
      else res.end();

      res.on("finish", () => {
        const entry = {
          ts: nowIso(),
          dur_ms: Date.now() - t0,
          method: "GET",
          path: req.originalUrl,
          upstream: upstreamUrl,
          status: r.status,
          bytes,
          content_type: ct,
          referer: req.headers["referer"] || null,
          ua: req.headers["user-agent"] || null,
          ip: clientIp(req)
        };
        logActivity(entry);
        console.log(`[GET] ${req.originalUrl} -> ${r.status} (${entry.dur_ms}ms, ${bytes || 0}B)`);
      });
    }
  } catch (e) {
    res.status(502).send("Upstream fetch error");
    const entry = {
      ts: nowIso(),
      dur_ms: Date.now() - t0,
      method: "GET",
      path: req.originalUrl,
      upstream: upstreamUrl,
      status: 502,
      error: "upstream_fetch_error",
      referer: req.headers["referer"] || null,
      ua: req.headers["user-agent"] || null,
      ip: clientIp(req)
    };
    logActivity(entry);
    console.log(`[GET] ${req.originalUrl} -> 502 (error)`);
  }
});

app.head(/.*/, async (req, res) => {
  const t0 = Date.now();
  const upstreamUrl = new URL(req.originalUrl, UPSTREAM).toString();
  try {
    const r = await fetch(upstreamUrl, { method: "HEAD" });
    res.status(r.status);
    r.headers.forEach((v, k) => res.setHeader(k, v));
    res.end();
    logActivity({
      ts: nowIso(),
      dur_ms: Date.now() - t0,
      method: "HEAD",
      path: req.originalUrl,
      upstream: upstreamUrl,
      status: r.status,
      ip: clientIp(req),
      ua: req.headers["user-agent"] || null
    });
    console.log(`[HEAD] ${req.originalUrl} -> ${r.status} (${Date.now() - t0}ms)`);
  } catch (e) {
    res.status(502).end();
    logActivity({
      ts: nowIso(),
      dur_ms: Date.now() - t0,
      method: "HEAD",
      path: req.originalUrl,
      upstream: upstreamUrl,
      status: 502,
      error: "upstream_fetch_error",
      ip: clientIp(req)
    });
    console.log(`[HEAD] ${req.originalUrl} -> 502 (error)`);
  }
});

// Blokiraj sve mutating metode (sigurnost) i zalogiraj pokušaj
for (const m of ["post","put","delete","patch","options"]) {
  app[m](/.*/, (req, res) => {
    logActivity({
      ts: nowIso(),
      dur_ms: 0,
      method: m.toUpperCase(),
      path: req.originalUrl,
      status: 200,
      note: "blocked_demo_mode",
      ip: clientIp(req),
      ua: req.headers["user-agent"] || null,
      referer: req.headers["referer"] || null
    });
    res.status(200).json({
      demo: true,
      message: "Demo nacin: zahtjev prema upstreamu je onemogucen."
    });
    console.log(`[${m.toUpperCase()} BLOCKED] ${req.originalUrl}`);
  });
}

// Mini pregled loga (zadnjih N linija) u browseru: https://www.pbz.hr/__proxy/logs?lines=200
app.get("/__proxy/logs", (req, res) => {
  const lines = Math.max(1, Math.min(1000, parseInt(req.query.lines || "200", 10)));
  if (!fs.existsSync(LOG_FILE)) return res.type("text/plain").send("No logs yet.");
  const content = fs.readFileSync(LOG_FILE, "utf8").trim().split(/\r?\n/);
  const tail = content.slice(-lines).join("\n");
  res.setHeader("content-type", "text/plain; charset=utf-8");
  res.send(tail);
});

// HTTPS server (pokreni PowerShell kao Administrator)
const opts = { key: fs.readFileSync(KEY), cert: fs.readFileSync(CERT) };
https.createServer(opts, app).listen(PORT, () => {
  console.log(`Exact-domain proxy s loggingom radi na https://www.pbz.hr/ (port ${PORT})`);
  console.log(`Otvori npr.: https://www.pbz.hr/gradjani/digitalno-bankarstvo.html`);
  console.log(`Pregled loga: https://www.pbz.hr/__proxy/logs`);
  console.log(`Log file: ${LOG_FILE}`);
});
